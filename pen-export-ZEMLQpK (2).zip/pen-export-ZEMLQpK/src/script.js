function myFunction() {
  // alert("thanks for visting")

  let header = (document.getElementByID("header").style.color = "red");
}
